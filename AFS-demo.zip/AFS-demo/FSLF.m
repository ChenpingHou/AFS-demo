
function [ACC,W,obj] = FSLF(A_1,A_2,A_4,A_6,Y,k,m,c,a,b)
% max tr(M'*S_1*M)+a*tr(W'*S*W)+ b*||H*M*M'*H*W*W'||_F^2,
% subject to M'M=I, ||M||_2,0 <= k;W'W=I, ||W||_2,0 <= k
% M is d_1-by-m, W is d-by-m
%% ��ʼ��
niter = 10;
S_1= cov(A_1); S = cov(A_2);
d1 = size(S_1,1);d2 = size(S,1);d3 = size(A_2,1);
M0 = Go(S_1, m, k); W0 = Go(S, m, k);
M = M0; W = W0;
WW = W(1:d1,:);
H = eye(d3)-ones(d3,d3)./d3;
TT = A_4'*H*A_4;
obj(1) = trace(M'*S_1*M)+a*trace(W'*S*W)+ b*trace(TT*M*M'*TT*WW*WW');

%% ����
for i = 2:niter
    WW = W(1:d1,:);
    A = S_1 + b*(TT*WW*WW'*TT);
    M = IPU(A, m, k, M);
    SS = zeros(d2,d2);
    SS(1:d1,1:d1) = TT*M*M'*TT;
    B = a*S + b*SS;
    W = IPU(B, m, k, W);
    WW = W(1:d1,:);
    obj(i) = trace(M'*S_1*M)+a*trace(W'*S*W)+ b*trace(TT*M*M'*TT*WW*WW');
    if i>1
        if (obj(i) - obj(i-1))/obj(i)<1e-8
            break
        end
    end
end

%% ����ѡ��
P=sqrt(sum(W.^2,2));
[~,Q]=sort(P,'descend');
X = A_6(:,Q(1:k,1));
 
%% K-means
acc=zeros(10,1);predY=cell(20);
G = zeros(1,8);
for t = 1:20
   [predY{t},~] = kmeansss(X',c);
   result(t,:) = MyClusteringMeasure(Y, predY{t});
   G = G +result(t,:);
end
ACC = 0.05.*G;

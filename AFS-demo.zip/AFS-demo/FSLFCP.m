function [ACC,M] = FSLFCP(A_3,A_4,Y,k,m,c);
S = cov(A_3);
d = size(S,1);
M0 = Go(S, m, k);
M = IPU(S, m, k, M0);
P=sqrt(sum(M.^2,2));
[~,Q]=sort(P,'descend');
PPP = A_4(:,Q(1:k,1));
predY=cell(20,1);G = zeros(1,8);
for t = 1:20
   [predY{t},~] = kmeansss(PPP',c);
   result(t,:) = MyClusteringMeasure(Y,predY{t});
   G = G +result(t,:);
end
ACC = 0.05.*G;

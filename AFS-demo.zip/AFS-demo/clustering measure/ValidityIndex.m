function [ S_Dbw ] = ValidityIndex(X,gnd  )
% S_Dbw defined in "Clustering Validity Assessment: Finding the optimal partitioning of a data set", ICDM, 2001 
%  written by Hong Tao, 2018.6.27
cL = unique(gnd);
nc = length(cL);

[~,nFea] = size(X);

%%%% calculate the centers of clusters.
c = zeros(nc,nFea);
stdvec = zeros(nc,nFea);  %%%% the standard deviation vector of each cluster
for i = 1:nc
    Xi = X(gnd == cL(i),:);
    c(i,:) = mean(Xi,1);
    stdvec(i,:) = std(Xi,1);
end
%%%% calculate the average standard deviation of clusters
stdev = mean(sqrt(sum(stdvec.*stdvec,2)));

%%%%% calculate the inter-cluster density (ID)
ID = 0;
for i = 1:nc
    Xi = X(gnd == cL(i),:);
    di = cal_density(Xi,c(i,:),stdev);
    for j = i+1 : nc
        uij = mean(c(i,:) + c(j,:),1);
        Xj = X(gnd == cL(j),:);
        Xij = [Xi; Xj];
        dij = cal_density(Xij,uij,stdev);
        dj = cal_density(Xj,c(j,:),stdev);
        ID = ID + dij/max(di,dj);
    end
end
ID = 2*ID/(nc-1)/nc;

Scat = stdev^2*nc/norm(std(X,1));

S_Dbw = ID/Scat;
end


function f = cal_density(data,c,stdev)

dist = pdist2(data,c);
f = sum(dist<=stdev);
end


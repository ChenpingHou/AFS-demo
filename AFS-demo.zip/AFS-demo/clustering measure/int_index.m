function results = int_index( X,gnd,distM,metric  )
% calculate internal clustering validation metric: dunn's index(DI), SilhouetteIndex (SI), S_Dbw 
% 
if nargin < 3
    distM=squareform(pdist(X));    %%%% calculate the distance between pairwise data points
end
if nargin < 4
    metric = 'Euclidean';
end
DI=dunns(X,gnd,distM);
SI  = SilhouetteIndex( X,gnd,metric);
S_Dbw  = ValidityIndex(X,gnd  );
results = [ DI, SI, S_Dbw ] ;
end


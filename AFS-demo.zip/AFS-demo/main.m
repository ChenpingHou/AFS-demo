%% 0.1
clc
close all

% load dataset
load mvPixraw10p.mat

work_space = whos;
for i = 1:size(work_space,1)
    space_i = work_space(i);
    if space_i.name == 'M'
        X = M;
    end
end
clear work_space
clear i
clear space_i

v1=4;v2=5;
% Preprocessing
XX = [X{v1},X{v2}];%%%%%%%%%%%%%%%%%%%%%%
XX = double(XX);
N = size(XX,1);
dd = size(XX,2);
XX = XX-ones(N,1)*((ones(1,N)*XX)./N);
XX = mapminmax(XX',0,1);
XX = XX';
%Y = gnd;
gnd_idx = unique(gnd);
cc = size(X{v1},2);%%%%%%%%%%%%%%%%%%%%%%%
n1p = 0.5; N1=fix(n1p*N);
n2p = 0.75; N2=fix(n2p*N);
c = max(gnd)-min(gnd)+1;

X1=[];X2=[];X3=[]; YY=[];
for ii=1:c
    idx = find(gnd==gnd_idx(ii));
    X1=[X1; XX(idx(1:fix(length(idx)*n1p)),:)];
    X2=[X2; XX(idx(fix(length(idx)*n1p)+1:fix(length(idx)*n2p)),:)];
    X3=[X3; XX(idx(fix(length(idx)*n2p)+1:end),:)];
    YY=[YY; gnd(idx(fix(length(idx)*n2p)+1:end),:)];
end
A_1 = X1(:,1:cc); % zuoshang
A_2 = X2; % xia
A_3 = [X1(:,1:cc);X2(:,1:cc)]; % zuo
A_4 = X2(:,1:cc); % zuoxia
A_5 = X3(:,1:cc);
A_6 = X3;
A1=cell(15,1);A2=cell(15,1);A3=cell(15,1);OBJ = cell(15,1);
A4=cell(15,1);
W1=cell(15,1);W2=cell(15,1);W3=cell(15,1);W10 = cell(15,1);
W4=cell(15,1);
                     
%% train                              
for fa = 1:25
    fp = 0.20+0.05*fix((fa-1)/5); % the rate of selected features;
    feature = fix(cc*fp); % the number of selected features
    dim = floor(2*feature/3); % the reduced dimension
    c_test = length(unique(YY));
    T1=cell(7,7); WW = cell(7,7); KK =[];
    for i = 1:7
        for j = 1:7
            a=10^(i-4);
            b=10^(j-4);
            [T1{i,j},WW{i,j},obj{i,j}] = FSLF(A_1,A_2,A_4,A_6,YY,feature,dim,c_test,a,b);
            KK = [KK;T1{i,j}];
        end
    end
    [mm]=find(KK(:,2)==max(KK(:,2)));
    o = ceil(mm(1)/7); p = mm(1)-7*(o-1);
    A1{fa} = T1{o,p}; W1{fa}=WW{o,p};OBJ{fa} = obj{o,p};
    
    %% IPU
    [A2{fa},W2{fa}] = FSLFCP(A_1,A_5,YY,feature,dim,c_test);
    [A3{fa},W3{fa}] = FSLFCP(A_3,A_5,YY,feature,dim,c_test);
    [A4{fa},W4{fa}] = FSLFCP(A_2,A_6,YY,feature,dim,c_test);

end
%% 0.1
Result = cell(5,1);Result_std = cell(5,1);
for j = 1:5
    ACC1_1=[];ACC2_1=[];ACC3_1=[];ACC4_1=[];
    for i = (5*j-4):(5*j)
        ACC1_1 = [ACC1_1;A1{i,1}];
        ACC2_1 = [ACC2_1;A2{i,1}];
        ACC3_1 = [ACC3_1;A3{i,1}];
        ACC4_1 = [ACC4_1;A4{i,1}];
    end
    AAM1_1 = max(ACC1_1,[],1);
    AAST1_1 = std(ACC1_1,0,1);
    AAM2_1 = mean(ACC2_1,1);
    AAST2_1 = std(ACC2_1,0,1);
    AAM3_1 = mean(ACC3_1,1);
    AAST3_1 = std(ACC3_1,0,1);
    AAM4_1 = mean(ACC4_1,1);
    AAST4_1 = std(ACC4_1,0,1);
    Result{j} = [AAM1_1;AAM2_1;AAM3_1;AAM4_1];
    Result_std{j} = [AAST1_1;AAST2_1;AAST3_1;AAST4_1];
end

  
